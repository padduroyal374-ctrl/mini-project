
let role="";
let products=JSON.parse(localStorage.getItem("products")||"[]");
let orders=JSON.parse(localStorage.getItem("orders")||"[]");

const app=document.getElementById("app");

function renderLogin(){
app.innerHTML=`
<div class='container'>
<h2>Login</h2>
<input id='email' placeholder='email'>
<input id='pass' type='password' placeholder='password'>
<button onclick='login()'>Login</button>
<button onclick='google()'>Continue with Google</button>
</div>`;
}

function login(){
roleSelect();
}

function google(){
roleSelect();
}

function roleSelect(){
app.innerHTML=`
<div class='container'>
<h3>Select Role</h3>
<button onclick="setRole('vendor')">Vendor</button>
<button onclick="setRole('customer')">Customer</button>
<button onclick="setRole('admin')">Admin</button>
</div>`;
}

function setRole(r){
role=r;
if(r==="vendor") vendorUI();
if(r==="customer") customerUI();
if(r==="admin") adminUI();
}

function vendorUI(){
app.innerHTML=`
<div class='container'>
<h2>Vendor Panel</h2>
<input id='name' placeholder='name'>
<input id='price' placeholder='price'>
<input id='qty' placeholder='quantity'>
<input id='cat' placeholder='category'>
<input type='file' id='img'>
<button onclick='addProduct()'>Add Product</button>
<div id='list'></div>
</div>`;
renderProducts();
}

function addProduct(){
let file=document.getElementById("img").files[0];
let reader=new FileReader();
reader.onload=function(){
let p={
id:Date.now(),
name:document.getElementById("name").value,
price:document.getElementById("price").value,
qty:document.getElementById("qty").value,
cat:document.getElementById("cat").value,
img:reader.result
};
products.push(p);
localStorage.setItem("products",JSON.stringify(products));
vendorUI();
}
if(file) reader.readAsDataURL(file);
}

function renderProducts(){
let list=document.getElementById("list");
if(!list) return;
list.innerHTML=products.map(p=>`
<div class='card product'>
<img src="${p.img}">
<h4>${p.name}</h4>
<p>₹${p.price}</p>
<p>Stock:${p.qty}</p>
<button onclick="del(${p.id})">Delete</button>
</div>
`).join("");
}

function del(id){
products=products.filter(p=>p.id!==id);
localStorage.setItem("products",JSON.stringify(products));
vendorUI();
}

function customerUI(){
app.innerHTML=`
<div class='container'>
<h2>Customer</h2>
<div id='plist'></div>
</div>`;
renderCustomer();
}

function renderCustomer(){
let list=document.getElementById("plist");
list.innerHTML=products.map(p=>`
<div class='card product'>
<img src="${p.img}">
<h4>${p.name}</h4>
<p>₹${p.price}</p>
<p>Stock:${p.qty}</p>
<button onclick='addCart(${p.id})'>Add to Cart</button>
</div>
`).join("");
}

let cart=[];

function addCart(id){
let p=products.find(x=>x.id===id);
cart.push(p);
alert("Added to cart");
}

function adminUI(){
app.innerHTML=`
<div class='container'>
<h2>Admin</h2>
${products.map(p=>`
<div class='card'>
${p.name} - ₹${p.price}
<button onclick="del(${p.id})">Delete</button>
</div>
`).join("")}
</div>`;
}

renderLogin();
